# junsircoding 的博客

## 介绍

我的博客系统源码，现系统已部署上线，网址：[http://junsircoding.info](http://junsircoding.info)。

这个系统我会长期维护，一边在系统中记录自己的学习笔记，一边将学会的技术应用到系统中。

系统源码编写是学习了[《Django企业开发实战》](https://item.jd.com/12537842.html)一书，作者 [the5fire](https://www.the5fire.com/)，我觉得讲的挺好。

ER 图是使用 [ponyorm](https://ponyorm.org/) 绘制，[系统库表 ER 图](https://editor.ponyorm.com/user/junsircoding/junsirblog/designer)。

![系统库表 ER 图](https://awesome-junjun-subscription-bucket-1300339528.cos.ap-guangzhou.myqcloud.com/junsirblog-images/junsirblog.png)


## 部署

部署方式是 Gunicorn 在本地运行服务，然后由 Nginx 做代理。

- 1.关闭 Gunicorn 服务
    ```shell
    ps -aux | grep gunicorn
    kill -9 [gunicorn进程号]
    ```
- 2.开启 Gunicorn 服务
    ```shell
    cd /root/junsirblog/typeidea
    gunicorn typeidea.wsgi:application -w 3 -k gthread -b 127.0.0.1:8000 --max-requests=10000 -D
    ```
- 3.重启 Nginx
    ```shell
    cd /usr/sbin/
    ./nginx -s reload
    ```

备份侧边栏
```html
      <div class="col-3">
        {% block sidebar %}
        {% for sidebar in sidebars %}
        <div class="card bg-light mb-3" style="max-width: 18rem;">
          <div class="card-body">
            <h5 class="card-title">{{ sidebar.title }}</h5>
          </div>
          {{ sidebar.content_html }}
        </div>
        {% endfor %}
        {% endblock %}
      </div>
```

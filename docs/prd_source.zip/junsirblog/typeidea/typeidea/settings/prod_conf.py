# -*- coding:utf-8 -*-
"""
:Date: 2021-08-11 16:42:14
:LastEditTime: 2021-08-11 16:42:14
:Description: 线上环境配置
"""
from .global_conf import *  # NOQA

DEBUG = False

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': "junsirblog_db",
        "USER": "root",
        "PASSWORD": "wangjun139",
        "HOST": "127.0.0.1",
        "PORT": 3306,
        "OPTIONS" : {
            "charset":"utf8mb4"
        },
        "CONN_MAX_AGE":60
    }
}
ALLOWED_HOSTS = [
    "junsircoding.info",
    "1.13.5.253",
]
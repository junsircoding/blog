# -*- coding:utf-8 -*-
"""
:Date: 2021-07-23 21:11:23
:LastEditTime: 2021-07-23 21:39:52
:Description: 开发环境配置文件
"""

from .global_conf import *  # NOQA

DEBUG = True

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': "junsirblog_db",
        "USER": "root",
        "PASSWORD": "wangjun139",
        "HOST": "127.0.0.1",
        "PORT": 3306,
        "OPTIONS" : {
            "charset":"utf8mb4"
        },
        "CONN_MAX_AGE":60
    }
}

ALLOWED_HOSTS = [
    "127.0.0.1",
]
